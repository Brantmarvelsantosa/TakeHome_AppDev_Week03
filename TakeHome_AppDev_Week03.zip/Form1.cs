﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TakeHome_AppDev_Week03
{
    public partial class Form1 : Form
    {
        List<string> Username = new List<string>();
        List<string> Password = new List<string>();
        List<int> Saldo = new List<int>();
        Point menu = new Point(12,12);
        Point registration = new Point(256,13);
        Point main = new Point(490, 13);
        Point deposit = new Point(13, 227);
        Point withdraw = new Point(256, 227);
        private int money = 0;
        private int deposits = 0;
        private int duit = 0;
        private int withdrawal = 0;
        
        public Form1()
        {
            InitializeComponent();
        }
  
        private void btn_login_Click(object sender, EventArgs e)
        {
            int saldos = Username.IndexOf(txt_user.Text);
            while(money != saldos)
            {
                if(money < saldos)
                {
                    money++;
                }
                else if(money> saldos)
                {
                    money--;
                }
            }

            if(txt_user.Text == "" &&  txt_password.Text == "")
            {
                MessageBox.Show("Username and Password not Found!");
            }
            else if (Username.IndexOf(txt_user.Text) == Password.IndexOf(txt_pass.Text)
                && Username.Contains(txt_user.Text) && Password.Contains(txt_pass.Text) )
            {
                btn_unhide.Visible = true;
                this.pnl_uang.Location = menu;
                lbl_uang.Text = Saldo[money].ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
                lbl_money.Text =Saldo[money].ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
                MessageBox.Show("Successfully Login");
            }
            else
            {
                MessageBox.Show("Username and Password not Found!");
            }
            txt_pass.Clear();
            txt_user.Clear();
        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            this.pnl_register.Location = menu;
            
        }

        private void btn_buat_Click(object sender, EventArgs e)
        {
            if (Username.Contains(txt_username.Text))
            {
                MessageBox.Show("Username has been used");
            }
            else
            {
                MessageBox.Show("Register Successful");
                Username.Add(txt_username.Text);
                Password.Add(txt_password.Text);
                Saldo.Add(0);
                this.pnl_register.Location = registration;
            }
            btn_muncul.Visible = true;
            txt_username.Clear();
            txt_password.Clear();
           
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            this.pnl_uang.Location = main;
            this.pnl_deposit.Location = deposit;
            this.pnl_withdraw.Location = withdraw;
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            this.pnl_deposit.Location = deposit;
            this.pnl_withdraw.Location = withdraw;
        }

        private void btn_deposit_Click(object sender, EventArgs e)
        {
            this.pnl_deposit.Location = menu;
        }

        private void btn_withdraw_Click(object sender, EventArgs e)
        {
            this.pnl_withdraw.Location = menu;
        }

        private void btn_transfer_Click(object sender, EventArgs e)
        {
            deposits = Convert.ToInt32(txt_deposit.Text);
            if (deposits <= 0)
            {
                MessageBox.Show("Deposit Amount Can't be less than 1");
            }
            else
            {
                Saldo[money] = Saldo[money] + deposits;
                lbl_uang.Text = Saldo[money].ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
                lbl_money.Text = Saldo[money].ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
                MessageBox.Show("Successfully Add Deposit");
                txt_deposit.Clear();
                this.pnl_deposit.Location = deposit;
            }
        }

        private void btn_tarik_Click(object sender, EventArgs e)
        {
     
            withdrawal = Convert.ToInt32(txt_withdraw.Text);
            if (Saldo[money] < withdrawal)
            {
                MessageBox.Show("Withdraw Failed. Not Enough Balance");
            }
            else if (withdrawal <= 0)
            {
                MessageBox.Show("Withdraw Amount Can't be less than 1");
            }
            else
            {

                Saldo[money] = Saldo[money] - withdrawal;
                lbl_uang.Text = Saldo[money].ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
                lbl_money.Text = Saldo[money].ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
                txt_withdraw.Clear();
                this.pnl_withdraw.Location = withdraw;
            }
        }

        private void btn_hide_Click(object sender, EventArgs e)
        {
            
           
        }

        private void btn_unhide_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_muncul_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_ilang_Click(object sender, EventArgs e)
        {
            
            
        }

        private void txt_pass_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txt_password_TextChanged(object sender, EventArgs e)
        {
            
        }

        
    }
}
